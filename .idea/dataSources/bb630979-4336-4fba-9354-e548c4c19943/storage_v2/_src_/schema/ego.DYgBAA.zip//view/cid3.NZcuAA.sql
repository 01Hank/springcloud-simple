create view cid3 as
select `ego`.`tb_category`.`parent_id` AS `parent_id`
from `ego`.`tb_category`
group by `ego`.`tb_category`.`parent_id`;

